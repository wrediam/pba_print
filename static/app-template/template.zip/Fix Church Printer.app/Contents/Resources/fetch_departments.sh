#!/bin/bash
# fetch_departments.sh
#
# Fetches the current department code list from the church's printer-admin
# server and prints it as tab-separated "code<TAB>label" lines, one per
# department -- the same format loadDepartmentCodes() in the AppleScript
# wrapper used to read from the old bundled department_codes.txt file, so
# no other parsing logic had to change. Bundled inside Fix Church
# Printer.app; called by the AppleScript wrapper, not meant to be run
# standalone (though it's safe to).
#
# Deliberately does NOT use python3/perl/ruby/git to parse the JSON. Those
# binaries exist at /usr/bin/* on every Mac whether or not Xcode Command
# Line Tools are installed, but actually running one without CLT installed
# pops a blocking "install the developer tools" dialog -- exactly the bad
# first-run experience this script exists to avoid. grep/sed/curl are true
# base-OS binaries with no such trampoline, so this is a hand-rolled parser
# instead of a real JSON library. It only has to handle the one flat shape
# this API returns -- an array of {"code": "...", "label": "..."} objects,
# both plain strings, no nesting -- not arbitrary JSON.
#
# Usage: fetch_departments.sh
# Prints "code<TAB>label" lines on success, or ERROR_FETCH_FAILED /
# ERROR_BAD_JSON on failure.

set -u

API_URL="http://192.168.8.235:3000/api/departments"

RESPONSE=$(curl -fsS --max-time 8 "$API_URL" 2>/dev/null)
if [[ $? -ne 0 || -z "$RESPONSE" ]]; then
	echo "ERROR_FETCH_FAILED"
	exit 1
fi

# One object per line, so each is a self-contained code/label extraction.
OBJECTS=$(echo "$RESPONSE" | tr -d '\n\r' | sed -E 's/\},[[:space:]]*\{/}\n{/g')

if [[ -z "$OBJECTS" ]]; then
	echo "ERROR_BAD_JSON"
	exit 1
fi

FOUND_ANY=0
while IFS= read -r obj; do
	[[ -z "$obj" ]] && continue
	code=$(echo "$obj" | grep -o '"code"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*:[[:space:]]*"(.*)"/\1/')
	label=$(echo "$obj" | grep -o '"label"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*:[[:space:]]*"(.*)"/\1/')
	if [[ -n "$code" && -n "$label" ]]; then
		printf '%s\t%s\n' "$code" "$label"
		FOUND_ANY=1
	fi
done <<< "$OBJECTS"

if [[ "$FOUND_ANY" -eq 0 ]]; then
	echo "ERROR_BAD_JSON"
	exit 1
fi
