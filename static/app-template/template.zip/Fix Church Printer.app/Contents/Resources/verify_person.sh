#!/bin/bash
# verify_person.sh <personalCode>
#
# Checks a personal code against the dashboard's people list, so the
# installer can catch an unknown/mistyped code up front instead of
# failing later at queue-provision time. Bundled inside Fix Church
# Printer.app; called by the AppleScript wrapper.
#
# Same "no python3/jq -> no Xcode Command Line Tools dialog" constraint as
# fetch_departments.sh: plain curl/grep/sed only.
#
# Prints one of:
#   VALID<TAB><name>    -- an active person with that code exists
#   INVALID             -- no such active person
#   ERROR_FETCH_FAILED  -- couldn't reach the dashboard

set -u

API_HOST="192.168.8.235:3000"
CODE="${1:-}"

if [[ -z "$CODE" ]]; then
	echo "INVALID"
	exit 0
fi

RESP=$(curl -fsS --max-time 8 "http://${API_HOST}/api/people/verify?code=${CODE}" 2>/dev/null)
if [[ $? -ne 0 || -z "$RESP" ]]; then
	echo "ERROR_FETCH_FAILED"
	exit 0
fi

if echo "$RESP" | grep -q '"valid"[[:space:]]*:[[:space:]]*true'; then
	NAME=$(echo "$RESP" | grep -o '"name"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*:[[:space:]]*"(.*)"/\1/')
	printf 'VALID\t%s\n' "$NAME"
else
	echo "INVALID"
fi
