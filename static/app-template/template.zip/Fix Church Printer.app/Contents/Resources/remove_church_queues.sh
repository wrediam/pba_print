#!/bin/bash
# remove_church_queues.sh
#
# Removes every church-copier CUPS queue on this Mac, whether it's an old
# direct-to-printer queue or a new gateway queue. Run once at the start of
# a rebuild, before add_profile_queue.sh recreates the fresh queues.
# Bundled inside Fix Church Printer.app.

set -u

# Legacy queues pointed straight at the copier; gateway queues point at
# the gateway instead. Rather than chase either IP, match by the queue
# NAME this app always uses ("Church_<deptcode>_<label>"), and also sweep
# any queue still pointed at the old printer IP for safety.
LEGACY_PRINTER_IP="192.168.1.222"

BY_NAME=$(lpstat -a 2>/dev/null | awk '{print $1}' | grep -E '^Church_' || true)
BY_IP=$(lpstat -v 2>/dev/null | grep -i "$LEGACY_PRINTER_IP" | sed -E 's/^device for ([^:]+):.*/\1/' || true)

# Union, de-duplicated.
EXISTING=$(printf '%s\n%s\n' "$BY_NAME" "$BY_IP" | sed '/^$/d' | sort -u)

if [[ -z "$EXISTING" ]]; then
	echo "DIAG_NOTHING_TO_REMOVE=1"
else
	while IFS= read -r q; do
		[[ -z "$q" ]] && continue
		OUT=$(lpadmin -x "$q" 2>&1)
		echo "DIAG_REMOVED=$q"
	done <<< "$EXISTING"
fi
echo "REMOVE_DONE"
