#!/bin/bash
# remove_church_queues.sh
#
# Removes every CUPS queue currently pointed at the church copier's IP,
# regardless of name. Meant to be run once at the start of a full
# rebuild, before add_profile_queue.sh creates the fresh per-department
# queues. Bundled inside Fix Church Printer.app.

set -u

PRINTER_IP="192.168.1.222"

EXISTING=$(lpstat -v 2>/dev/null | grep -i "$PRINTER_IP" | sed -E 's/^device for ([^:]+):.*/\1/' || true)

if [[ -z "$EXISTING" ]]; then
	echo "DIAG_NOTHING_TO_REMOVE=1"
else
	for q in $EXISTING; do
		OUT=$(lpadmin -x "$q" 2>&1)
		echo "DIAG_REMOVED=$q"
	done
fi
echo "REMOVE_DONE"
