#!/bin/bash
# fetch_departments.sh
#
# Fetches the current department code list from the church's printer-admin
# server and prints it as tab-separated "code<TAB>label" lines, one per
# department -- the same format loadDepartmentCodes() in the AppleScript
# wrapper used to read from the old bundled department_codes.txt file, so
# no other parsing logic had to change. Bundled inside Fix Church
# Printer.app; called by the AppleScript wrapper, not meant to be run
# standalone (though it's safe to).
#
# Usage: fetch_departments.sh
# Prints "code<TAB>label" lines on success, or ERROR_FETCH_FAILED /
# ERROR_BAD_JSON on failure.

set -u

API_URL="http://192.168.8.235:3000/api/departments"

RESPONSE=$(curl -fsS --max-time 8 "$API_URL" 2>/dev/null)
if [[ $? -ne 0 || -z "$RESPONSE" ]]; then
	echo "ERROR_FETCH_FAILED"
	exit 1
fi

echo "$RESPONSE" | /usr/bin/python3 -c '
import json, sys
try:
	data = json.load(sys.stdin)
	for item in data:
		code = str(item.get("code", "")).strip()
		label = str(item.get("label", "")).strip()
		if code and label:
			print(code + "\t" + label)
except Exception:
	print("ERROR_BAD_JSON")
	sys.exit(1)
'
