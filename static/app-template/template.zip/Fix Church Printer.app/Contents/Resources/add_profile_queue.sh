#!/bin/bash
# add_profile_queue.sh
#
# Creates one CUPS queue for one department profile on the church copier.
# Called once per selected department by the AppleScript wrapper, after
# remove_church_queues.sh has already cleared out anything old. Installs
# the real BP-71C65 driver itself from files bundled in this app if it's
# missing on this Mac. Bundled inside Fix Church Printer.app.
#
# Usage: add_profile_queue.sh <FullCode> <DeptCode> <DeptLabel> <RealUser>
#   FullCode   the complete code to embed (personal code + dept code)
#   DeptCode   the department's own code, e.g. 61
#   DeptLabel  human-readable department name, e.g. "Youth Dept."
#   RealUser   the actual logged-in macOS account (see note below)

set -u

PRINTER_IP="192.168.1.222"
PPD_MATCH="BP-71C65 PPD"

# The actual hardware configuration on this copier (Input Tray Options:
# Four Trays, Large Capacity Tray: BP-LC10, Output Tray Options: Saddle
# Stitch Finisher (Large Stacker), Punch Module: 3 Holes, Job Separator:
# on, Folding Unit: off, Right Tray: on, Data Security Kit: on). Applied
# to every queue this script creates so print jobs actually use the
# installed trays/finisher instead of the PPD's bare defaults.
HARDWARE_OPTS=(
	-o Option5=3TrayDrawer
	-o Option6=Installed
	-o Option1=LSSFinisher
	-o Option9=PModule33
	-o Option3=True
	-o Option7=False
	-o Option2=True
	-o Option4=True
)

FULL_CODE="${1:-}"
DEPT_CODE="${2:-}"
DEPT_LABEL="${3:-Department}"
REAL_USER="${4:-$(whoami)}"

if [[ -z "$FULL_CODE" || -z "$DEPT_CODE" ]]; then
	echo "ERROR_MISSING_ARGS"
	exit 1
fi

# The per-user "lpoptions" default (see below) has to land in the actual
# logged-in person's ~/.cups/lpoptions, not root's. When this script runs
# elevated ("with administrator privileges"), $(whoami) here is root, so
# the caller passes the real username explicitly and we run that one
# command as them via sudo -u -- root can always do that without a
# password prompt.
run_as_real_user() {
	if [[ "$(id -u)" == "0" ]]; then
		sudo -u "$REAL_USER" -H "$@"
	else
		"$@"
	fi
}

# Build a safe CUPS queue name from the department code + label.
SAFE_LABEL=$(echo "$DEPT_LABEL" | sed -E 's/[^A-Za-z0-9]+/_/g' | sed -E 's/^_+|_+$//g' | cut -c1-40)
QUEUE_NAME="Church_${DEPT_CODE}_${SAFE_LABEL}"
DESCRIPTION="Church Copier - ${DEPT_LABEL}"

echo "DIAG_QUEUE_NAME=$QUEUE_NAME"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SYSTEM_PPD_DIR="/Library/Printers/PPDs/Contents/Resources"
SYSTEM_FILTER_DIR="/Library/Printers/Sharp/Filters"
BUNDLED_PPD="$SCRIPT_DIR/SHARP BP-71C65.PPD.gz"
BUNDLED_FILTER="$SCRIPT_DIR/pstomx3061ps.app"

if ! lpinfo -m 2>/dev/null | grep -qi "$PPD_MATCH"; then
	if [[ ! -f "$BUNDLED_PPD" ]] || [[ ! -d "$BUNDLED_FILTER" ]]; then
		echo "ERROR_DRIVER_MISSING"
		exit 2
	fi
	mkdir -p "$SYSTEM_PPD_DIR"
	cp "$BUNDLED_PPD" "$SYSTEM_PPD_DIR/"
	mkdir -p "$SYSTEM_FILTER_DIR"
	cp -R "$BUNDLED_FILTER" "$SYSTEM_FILTER_DIR/"
	chmod +x "$SYSTEM_FILTER_DIR/$(basename "$BUNDLED_FILTER")/Contents/MacOS/"* 2>/dev/null
	echo "DIAG_INSTALLED_DRIVER=1"
fi

RAW_LINE=$(lpinfo -m 2>/dev/null | grep -i "$PPD_MATCH" | head -1)
if [[ -z "$RAW_LINE" ]]; then
	echo "ERROR_DRIVER_MISSING"
	exit 2
fi
PPD_MODEL=$(echo "$RAW_LINE" | sed -E 's/^(.*\.gz) .*/\1/')

lpstat -p "$QUEUE_NAME" >/dev/null 2>&1 && lpadmin -x "$QUEUE_NAME" >/dev/null 2>&1 || true

CREATE_OUT=$(lpadmin -p "$QUEUE_NAME" -E -v "ipp://${PRINTER_IP}/" -m "$PPD_MODEL" -D "$DESCRIPTION" -L "$PRINTER_IP" "${HARDWARE_OPTS[@]}" 2>&1)
echo "DIAG_CREATE_RC=$?"
echo "DIAG_CREATE_OUT=$CREATE_OUT"

OPTS_OUT=$(lpoptions -p "$QUEUE_NAME" -l 2>&1)
if echo "$OPTS_OUT" | grep -q ARUserNumber; then
	# lpadmin's default only shows up in the compiled PPD for reference --
	# it is NOT what actually gets embedded when someone prints normally
	# (confirmed: a job sent with no explicit option came back logged as
	# "N/A" on the printer, meaning no account at all). The per-USER
	# default set via lpoptions is what real print jobs -- from any app,
	# not just the command line -- actually pick up automatically. Set
	# both so the queue is self-documenting and jobs are correctly coded.
	SET_OUT=$(lpadmin -p "$QUEUE_NAME" -o "ARUserNumber=Custom.${FULL_CODE}" 2>&1)
	echo "DIAG_SET_OUT=$SET_OUT"
	LPOPT_OUT=$(run_as_real_user lpoptions -p "$QUEUE_NAME" -o "ARUserNumber=Custom.${FULL_CODE}" 2>&1)
	echo "DIAG_LPOPTIONS_OUT=$LPOPT_OUT"
	echo "QUEUE_READY"
else
	echo "DIAG_OPTIONS_START"
	echo "$OPTS_OUT"
	echo "DIAG_OPTIONS_END"
	echo "QUEUE_MISMATCH"
fi
