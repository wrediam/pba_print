#!/bin/bash
# add_profile_queue.sh  (print-gateway model)
#
# Creates one local CUPS queue that points at the church print GATEWAY,
# for one department profile. Called once per selected department by the
# AppleScript wrapper, after remove_church_queues.sh has cleared old
# queues. Bundled inside Fix Church Printer.app.
#
# The account code is NO LONGER embedded here. It lives on a queue the
# gateway owns; this script just asks the dashboard to make sure that
# gateway queue exists, then points a local queue at the URI it returns.
# See docs/GATEWAY_MIGRATION.md in the pba_print repo for the full story.
#
# Usage: add_profile_queue.sh <FullCode> <DeptCode> <DeptLabel> <RealUser>
#   FullCode   personal code + dept code, e.g. 598 + 61 = 59861
#   DeptCode   the department's own code, e.g. 61
#   DeptLabel  human-readable department name, e.g. "Youth Dept."
#   RealUser   the logged-in macOS account (accepted for arg-compat with
#              the AppleScript wrapper; not needed in this model)

set -u

# The dashboard that fronts the gateway -- same host fetch_departments.sh
# already talks to. It returns the client-reachable ipp:// URI to use.
DASHBOARD_HOST="192.168.8.235:3000"
PROVISION_URL="http://${DASHBOARD_HOST}/api/gateway/provision"

# Installed-hardware options, so the print dialog EXPOSES the copier's
# trays/finisher/punch (Four Trays, Large Capacity Tray, Saddle Stitch
# Finisher, 3-Hole Punch, Job Separator, Right Tray). These only enable
# the UI for those options -- they do NOT force any per-job choice, and
# they carry NO account code or color mode (both of those live on the
# gateway queue now, never here -- that's the whole point of the
# migration). Same Option names as the gateway's Linux PPD (same driver
# family).
HARDWARE_OPTS=(
	-o Option5=3TrayDrawer
	-o Option6=Installed
	-o Option1=LSSFinisher
	-o Option9=PModule33
	-o Option3=True
	-o Option7=False
	-o Option2=True
	-o Option4=True
)

FULL_CODE="${1:-}"
DEPT_CODE="${2:-}"
DEPT_LABEL="${3:-Department}"
REAL_USER="${4:-$(whoami)}"

if [[ -z "$FULL_CODE" || -z "$DEPT_CODE" ]]; then
	echo "ERROR_MISSING_ARGS"
	exit 1
fi

# personCode = FullCode with the trailing DeptCode stripped off. The
# AppleScript wrapper builds FullCode as personalCode + deptCode, so the
# dept code is always the suffix.
PERSON_CODE="${FULL_CODE%"$DEPT_CODE"}"
if [[ -z "$PERSON_CODE" ]]; then
	echo "ERROR_BAD_CODE"
	exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLED_PPD="$SCRIPT_DIR/Sharp-BP-71C65-ps.ppd"

SAFE_LABEL=$(echo "$DEPT_LABEL" | sed -E 's/[^A-Za-z0-9]+/_/g' | sed -E 's/^_+|_+$//g' | cut -c1-40)
QUEUE_NAME="Church_${DEPT_CODE}_${SAFE_LABEL}"
DESCRIPTION="Church Copier - ${DEPT_LABEL}"
echo "DIAG_QUEUE_NAME=$QUEUE_NAME"

# 1. Ask the gateway (via the dashboard) to ensure the coded queue exists.
#    Hand-rolled request/parse, same reasoning as fetch_departments.sh:
#    no python3/jq, so a Mac without Xcode Command Line Tools doesn't get
#    the blocking "install developer tools" dialog.
BODY="{\"personCode\":\"${PERSON_CODE}\",\"departmentCode\":\"${DEPT_CODE}\"}"
RESP=$(curl -fsS --max-time 12 -H "Content-Type: application/json" -X POST -d "$BODY" "$PROVISION_URL" 2>/dev/null)
if [[ $? -ne 0 || -z "$RESP" ]]; then
	echo "DIAG_PROVISION_RESP=$RESP"
	echo "ERROR_PROVISION_FAILED"
	exit 3
fi
echo "DIAG_PROVISION_RESP=$RESP"

GATEWAY_URI=$(echo "$RESP" | tr -d '\n\r' | grep -o '"uri"[[:space:]]*:[[:space:]]*"[^"]*"' | sed -E 's/.*:[[:space:]]*"(.*)"/\1/')
if [[ -z "$GATEWAY_URI" ]]; then
	echo "ERROR_NO_URI"
	exit 3
fi
echo "DIAG_GATEWAY_URI=$GATEWAY_URI"

if [[ ! -f "$BUNDLED_PPD" ]]; then
	echo "ERROR_PPD_MISSING"
	exit 2
fi

# 2. Point a local queue at the gateway queue, using the bundled Linux
#    PostScript PPD so all finishing options appear in the print dialog.
#    No ARUserNumber, no ARCMode, no per-user lpoptions -- the gateway
#    queue owns the code and color policy.
lpstat -p "$QUEUE_NAME" >/dev/null 2>&1 && lpadmin -x "$QUEUE_NAME" >/dev/null 2>&1 || true

CREATE_OUT=$(lpadmin -p "$QUEUE_NAME" -E -v "$GATEWAY_URI" -P "$BUNDLED_PPD" -D "$DESCRIPTION" -L "church gateway" "${HARDWARE_OPTS[@]}" 2>&1)
CREATE_RC=$?
echo "DIAG_CREATE_RC=$CREATE_RC"
echo "DIAG_CREATE_OUT=$CREATE_OUT"

if [[ "$CREATE_RC" -eq 0 ]] && lpstat -p "$QUEUE_NAME" >/dev/null 2>&1; then
	echo "QUEUE_READY"
else
	echo "QUEUE_CREATE_FAILED"
fi
