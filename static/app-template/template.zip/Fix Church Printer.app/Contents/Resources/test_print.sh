#!/bin/bash
# test_print.sh
#
# Sends a one-page test print to the given queue and watches to see
# whether it actually completes or gets stuck.
#
# Usage: test_print.sh <QueueName>
# Prints TEST_COMPLETED or TEST_STUCK.

set -u

QUEUE_NAME="${1:-}"
if [[ -z "$QUEUE_NAME" ]]; then
	echo "ERROR_NO_QUEUE"
	exit 1
fi

T=$(mktemp /tmp/church_test.XXXXXX.txt)
{
	echo "Church printer test"
	echo "Queue: $QUEUE_NAME"
	echo "Host: $(scutil --get ComputerName 2>/dev/null || hostname)"
	echo "User: $(whoami)"
	echo "Date: $(date)"
} > "$T"

JOB=$(lp -d "$QUEUE_NAME" "$T" 2>&1 | sed -E 's/request id is ([^ ]+).*/\1/')
rm -f "$T"

DONE=0
for i in $(seq 1 15); do
	sleep 2
	if ! lpstat -o "$QUEUE_NAME" 2>/dev/null | grep -q "$JOB"; then
		DONE=1
		break
	fi
done

if [[ "$DONE" == "1" ]]; then
	echo "TEST_COMPLETED"
else
	echo "TEST_STUCK"
fi
